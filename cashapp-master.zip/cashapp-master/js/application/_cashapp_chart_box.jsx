import React from "react";

class CashappChartBox extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return(
            <div className="cashapp-chart-box window">
                
            </div>
        );
    }
}

export default CashappChartBox;
