import React from "react";

class CashappHeader extends React.Component {
    render() {
        return(
            <header className="cashapp-header window">
                <h1>cashapp</h1>
            </header>
        );
    }
}

export default CashappHeader;
